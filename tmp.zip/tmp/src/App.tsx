import React from 'react';
import './App.css';
import Navbar from './components/Navbar';
import Welcome from './components/Welcome';
import PhpAcademy from './components/phpacademy';
import Experience from './components/Experience';
import Discover from './components/Discover';
import Timeline from './components/Timeline';
import Application from './components/Application';
import Location from './components/Location';
import Footer from './components/Footer';
import Price from './components/Price';
import Line from './components/Line';
import Dates from './components/Dates';


function App() {
  return (
    <>
      
      <Welcome />
      <Navbar />
      <PhpAcademy />
      <Experience />
      <Discover />
      <Timeline />
      <Price />
      <Dates />
      <Application/>    
      <Location />
      <Footer />
      <Line />
   
    </>
  );

}

export default App;
