import React from "react"; 
import BtnDate from "./extend/Btn/BtnPrm";

function Dates() 
{ 
    return (
        <>
        <div id="dates" className="bg-[url('images/poly-grey.png')] bg-repeat bg-[position:center]">
            <div className="p-[100px_0] m-[0_auto] w-[100%]">
                <div className="ml-auto mr-auto mb-[20px]">
                    <div className="ml-[25%] w-[50%] text-center">
                        <h4 className="text-[2.28rem] m-[1.52rem_0_0.912rem_0] font-medium">DATES</h4>
                        <p>Get the edge over others thanks to PHP Academy</p>
                    </div>
                </div>
                <div className="ml-auto mr-auto mb-[20px] md:block text-center grid justify-items-center">
                    <div className="w-[100%] ml-auto text-center m-[50px_0] "></div>
                    <BtnDate description={"7.2. - 11.2.2022"}/>
                    <BtnDate description={"4.4. - 8.4.2022"}/>
                    <BtnDate description={"6.6 - 10.6.2022"}/>
                </div>
            </div>

        </div>
        </>
        )
}
export default Dates;