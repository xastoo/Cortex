import React from "react";
import BtnPrm from "./extend/Btn/BtnPrm";

function Price () { 
    return ( 
        <section id="price" className="bg-primary bg-[url('images/details.png')] md:p-[100px] p-[120px_0]">
  <div className="py-15 px-4 mx-auto max-w-screen-xl lg:py-16 lg:px-6">
      <div className="mx-auto max-w-screen-md text-center mb-8 lg:mb-12">
          <h2 className="mb-4 md:text-5xl text-3xl tracking-tight font-medium text-[#DCDCDC]">TRAINING PRICE</h2>
          <p className="mb-5 text-gray-500 sm:text-xl dark:text-gray-400">CHOOSE THE ONE</p>
      </div>
      <div className="space-y-8 lg:grid lg:grid-cols-3 sm:gap-6 xl:gap-10 lg:space-y-0 perspective-5">

          <div className="bg-[#ffffff] flex flex-col p-6 mx-auto max-w-lg text-center text-gray-900 bg-white rounded-lg shadow dark:border-gray-600 xl:p-8 dark:bg-gray-800 dark:text-white">
              <h3 className="mb-2 text-2xl font-semibold text-primary">Early Access</h3>
              <div className="flex justify-center items-baseline my-8">
                  <span className="mr-2 text-4xl font-medium text-primary center">€ 299 incl VAT</span>
              </div>
              <p className="mb-2">SIGN UP EARLY AND ENJOY DISCOUNT.</p>
              <p className="mb-4">For registrations more than a month before the start date.</p>
              <BtnPrm description="Sign Up"/>
              <p>For older than 26 years. Suitable for professionals and enthusiasts aiming to expand their knowledge in OOP programming.</p>
              
          </div>
    
          <div className="bg-[#ffffff] flex flex-col p-6 mx-auto max-w-lg text-center text-gray-900 bg-white rounded-lg shadow dark:border-gray-600 xl:p-8 dark:bg-gray-800 dark:text-white">
              <h3 className="mb-2 text-2xl font-semibold text-primary">Student Academy</h3>
              <div className="flex justify-center items-baseline my-8">
                  <span className="mr-2 text-4xl font-medium text-primary center">Only € 20* incl VAT</span>
              </div>
              <p className="mb-2">Common student price € 199</p>
              <p className="mb-4">For students under 26 years.</p>
              <BtnPrm description="Sign Up"/>
              <p> * Are you a student, and you want to get the lowest possible price? Use our cash-back bonus! Have 100 % training attendance, fulfill all assignments, and then prove your newly gained knowledge at Cortex. After the full payment and meeting the conditions, we will cash you back € 180. Then the training costs only € 20!</p>
              
          </div>
   
          <div className="bg-[#ffffff] flex flex-col p-6 mx-auto max-w-lg text-center text-gray-900 bg-white rounded-lg  shadow dark:border-gray-600 xl:p-8 dark:bg-gray-800 dark:text-white">
              <h3 className="mb-2 text-2xl font-semibold text-primary">Regular Access</h3>
              <div className="flex justify-center items-baseline my-8">
                  <span className="mr-2 text-4xl font-medium text-primary center">€ 399 incl VAT</span>
              </div>
              <p className="mb-2">GET PRACTICAL TRAINING FOR A FAIR PRICE.</p>
              <p className="mb-4">For older than 26 years.</p>
              <BtnPrm description="Sign Up"/>
              <p>Suitable for professionals and enthusiasts aiming to expand their knowledge in OOP programming.</p>
              
          </div>
      </div>
  </div>
</section>
    )
}
export default Price;