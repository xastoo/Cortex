import React from "react"; 

function Line() 
{ 
    return (
        <div className="bg-[#2e2d2d] text-center">
            <p className="text-[#ffffff] p-[15px_0]"><span className="text-primary">PHP Academy </span>is provided and operated by © Cortex 2023</p>
        </div>
    )
}
export default Line;