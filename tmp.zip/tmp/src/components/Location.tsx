import React, { useState } from "react"; 


function Location() 
{ 
    const [isShown, setIsShown] = useState(false);

    const handleClick = (event: any) => {

      setIsShown((current: any) => !current);
  
    };

    return (
        <div>
            {!isShown && (
            <div id="location" className="bg-[url('images/maps.png')] bg-no-repeat bg-[position:center] h-[150px] items-center flex justify-center">
                <h5 className="text-[#ffffff] md:text-[1.6rem] cursor-pointer font-medium">WHERE WILL YOU FIND US?</h5>
                <i onClick={handleClick} className="font-['Material_Symbols_Outlined'] text-[25px] m-[6px_0_0_10px] text-primary cursor-pointer not-italic">expand_circle_down</i>
            </div>
            )}
            {isShown && (
            <div className="Map">
                <i onClick={handleClick} className="not-italic left-[50%] rotate-180 absolute font-['Material_Symbols_Outlined'] text-[25px] m-[6px_0_0_10px] text-primary cursor-pointer">expand_circle_down</i>
                <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d3619.0139110794325!2d14.519545949106481!3d50.104458960012224!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1scortex!5e0!3m2!1scs!2scz!4v1685341304649!5m2!1scs!2scz" className="w-[100%] h-[300px]"></iframe>
            </div>
            )}
        </div>
    )
}

export default Location;
