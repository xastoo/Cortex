import React from "react"; 
import BtnPrm from "./extend/Btn/BtnPrm";

function Experience() 
{ 
    return (
        
        <div className="md:border-0 border-t-2 border-primary xl:bg-[url('images/light-lamp.png'),_url('images/o-co-ziskam.png')] bg-no-repeat bg-[position:left_40px_top,_left_85%_center] bg-lenght[auto, auto] bg-[#fafafa]">
            <div className="p-[100px_0] w-[70%] m-[0_auto]">
                <div className="ml-auto mr-auto mb-[20px]">
                    <div className="xl:w-[50%] ml-0 w-[100%]">
                        <div className="relative mb-[24px] xl:ml-[40px] text-center">
                            <h1 className="m-0 xl:text-5xl text-4xl text-gray-300 font-medium ">WHAT WILL I GAIN?</h1>
                            <h5 className="m-0 xl:ml-[5em] font-medium">BY GRADUATING PHP ACADEMY</h5>
                        </div>
                        <p className="md:mb-0 mb-[20px]">At the end of the training, you will acquire:</p>
                        <ul className="xl:m-[50px_0] mb-[20px]">
                            <li className=" list-none leading-[22px]">
                                <i>Essential knowledge for Object-Oriented Programming</i>
                            </li>
                            <li className=" list-none leading-[22px]">
                                <i>Access to online lectures</i>
                            </li>
                            <li className=" list-none leading-[22px]">
                                <i>Practical tips & tricks for more effective PHP use</i>
                            </li>
                            <li className=" list-none leading-[22px]">
                                <i>Graduation certificate</i>
                            </li>
                        </ul>
                        <div className="text-center xl:text-left">
                        <BtnPrm description="Sign Up"/>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    )
}
export default Experience;