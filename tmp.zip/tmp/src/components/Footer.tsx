import React from "react"; 
import FooterTextH5 from "./extend/Text/FooterTextH5";



function Footer() 
{ 
    return (
        <div className="bg-[url('images/poly-grey.png')] bg-repeat bg-[position:center]">
            <div className="p-[15px_0] w-[70%] m-[0_auto] max-w-[100%]">
                <div className="mb-[0px] flex flex-wrap text-center">
                    <div className="self-center xl:w-[33.33%] ml-auto w-[100%] xl:border-0 border-b-2 border-primary">
                        <FooterTextH5 description="Contacts"/>
                        <p className="md:text-[1rem] text-[0.8rem]">Cortex, a.s.<br />U Elektry 974/1c,<br />190 00 Praha</p>
                    </div>
                    <div className="self-center xl:w-[33.33%] ml-auto xl:border-r-2 border-primary xl:border-l-2 w-[100%]">
                        <FooterTextH5 description="Phone"/>
                        <p className="md:text-[1rem] text-[0.8rem]">+420 266 610 465</p>
                        <h5 className="mt-0 md:text-[1.64rem] text-[1.3rem] font-semibold">Email</h5>
                        <p className="md:text-[1rem] text-[0.8rem]">phpacademy@cortex.cz</p>
                    </div>
                    <div className="self-center xl:w-[33.33%] ml-auto w-[100%] xl:border-0 border-t-2 border-primary">
                        <p className="md:text-[1rem] text-[0.8rem]">IČO: 471 256 16, DIČ: CZ 471 256 16<br />Cortex, a.s. is registered in commercial register<br />by the Prague Municipal court,<br />section C, entry 13052</p>
                    </div>
                </div>
            </div>
        </div>

    )
}

export default Footer;