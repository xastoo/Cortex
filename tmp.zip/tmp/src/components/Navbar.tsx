import React, { useState } from "react"; 
import NavbarItems from "./extend/NavbarItems";


function Navbar() 
{ 

    const [isShown, setIsShown] = useState(false);

    const handleClick = (event: any) => {

      setIsShown((current: any) => !current);
  
    };
    return (
        
            <div className="sticky shadow-[0_2px_2px_0_rgba(0,0,0,0.14),0_3px_1px_-2px_rgba(0,0,0,0.12),0_1px_5px_0_rgba(0,0,0,0.2)] overflow-hidden top-0 z-10"> 
                <nav className="bg-[#2a2a2a] text-white md:h-[64px] md:leading-[64px]"> 
                    <div className="h-full relative"> 
                    
                        <ul className="text-center md:block hidden"> 
                            
                            <li className="inline-block text-[#f55d4b] transition duration-300 ease-in-out hover:bg-[#000000]"> 
                                <a href="/" className="uppercase md:px-[15px] md:py-[21px]">Home </a> 
                            </li> 
                            <NavbarItems link="phpacademy" description="About academy" />
                            <NavbarItems link="price" description="prices" />
                            <NavbarItems link="dates" description="dates" />
                            <NavbarItems link="reservation" description="reservations" />
                            <NavbarItems link="location" description="contact us" />
                        </ul> 
                        {!isShown && (
                        <div>
                        <i onClick={handleClick} className="font-['Material_Symbols_Outlined'] text-primary text-3xl cursor-pointer md:hidden block not-italic">menu</i>
                        </div>
                        )}
                        {isShown && (
                            <ul onClick={handleClick} className="text-center grid "> 
                            <i className="font-['Material_Symbols_Outlined'] text-primary text-3xl cursor-pointer md:hidden block not-italic float-left">close</i>
                            <br />  
                            <li className="inline-block text-[#f55d4b] transition duration-300 ease-in-out hover:bg-[#000000] mb-[20px]"> 
                                <a href="/" className="uppercase md:px-[15px] md:py-[21px]">Home </a> 
                            </li> 
                            <br />
                            
                            <NavbarItems link="phpacademy" description="About academy" />
                            <br />
                            <NavbarItems link="price" description="prices" />
                            <br />
                            <NavbarItems link="dates" description="dates" />
                            <br />
                            <NavbarItems link="reservation" description="reservations" />
                            <br />
                            <NavbarItems link="location" description="contact us" />
                            <br />
                        </ul> 
                        )}
                    </div> 
                </nav> 
            </div>
    ) 
} 
export default Navbar;