import { useState } from "react";
import "../App.css"

const Welcome: React.FC = () => {
  const [offsetX, setOffsetX] = useState(0);
  const [offsetY, setOffsetY] = useState(0);

  const handleMouseMove = (event: React.MouseEvent<HTMLUListElement>) => {
    const { clientX, clientY } = event;
    setOffsetX(clientX);
    setOffsetY(clientY);
  };

  const ulStyle: React.CSSProperties = {
    position: 'relative',
    overflow: 'hidden',
    height: 'calc(100vh - 64px)',
    width: '100%',
  };

  const manStyle: React.CSSProperties = {
    transform: `translate(${0}px, ${offsetY * -0.04}px)`,
  };

  const circleStyle: React.CSSProperties = {
    transform: `translate(${offsetX * -0.04}px, ${0}px)`,
  };
   

  return (
    <>
      <div className="w-[100%]">
        <div className="md:absolute md:top-2/4 top-[100px] z-[1] md:translate-x-[20%] md:translate-y-[-50%] hover:transition-transform relative">
          <div className="p-[34px_0_34px_19px] bg-[url('images/ellipse.png')] xl:bg-[length:191px_191px] bg-no-repeat bg-left mb-[20px] bg-[length:150px_150px]">
            <div className="pr-3">
              <h4 className="md:text-[1.5em] xl:text-[2.3em] text-[1.5em] width-screen text-center">
                <span className="md:text-[#ffffff]">Gain Basic</span> Knowledge for E-Shop Creation
              </h4>
              <h2 className="uppercase md:text-[52px] text-[1.2em] md:text-left text-center">
                <span className="md:text-[#ffffff] pr-[12px]">#PHP</span> Academy
              </h2>
            </div>
          </div>
          <div className="  mb-5 p-[0_0.75rem] md:text-left text-center ">
            <div className="w-full ml-auto">
              <p className="leading-6">Experience training focused on tools and principles.</p>
            </div>
          </div>
          <div className="md:mb-[20px]">
            <div className="p-[0_0.75rem] md:text-left text-center">
              <a
                href="/"
                className="rounded-full border border-[#444444] p-[7px_32px] m-[10px] w-[83.333333%] cursor-pointer transition duration-200 ease-in-out hover:bg-primary hover:text-[#ffffff] hover:border-primary"
              >
                Sign Up
              </a>
              </div>
              </div>
          
          </div>
          <ul className="relative overflow-hidden h-[calc(100vh-64px)] w-full" onMouseMove={handleMouseMove} style={ulStyle}>
            <li id="man" style={manStyle}></li>
            <li id="circle" style={circleStyle}></li>
            <li className="absolute w-full h-full xl:bg-[url('images/test2.png')] bg-no-repeat bg-[right_5%_bottom] bg-[size:32%]"></li>
          </ul>          
      </div>
    </>
  );
};

export default Welcome;
