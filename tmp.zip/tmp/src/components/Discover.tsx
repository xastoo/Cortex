import React from "react"; 
let styles = require("../index.css");
function Discover() 
{ 
    return (
            <div id="discovery" className="bg-[position:left_center,_center] text:center text-white">
                <div className="p-[160px_0] xl:w-[70%] text:center m-[0_auto] max-w-7xl">
                    <div className="ml-auto mr-auto mb-[20px]">
                        <div className="md:ml-[25%] md:w-[50%] text-center w-100% md:m-auto m-[0_10px]">
                            <h4 className="xl:text-[2.28rem] text-[1.6rem] font-medium m-[1.52rem_0_0.92rem_0] text-[#ffffff]">DISCOVER THE WORLD OF PHP ACADEMY</h4>
                            <p className="leading-[22px] text-[#ffffff]">Sign up for PHP Academy training to learn everything necessary to make programming your dream job.</p>
                        </div>
                        <div className="ml-auto mr-auto mb-[20px]">
                            <div className="text-center mt-[40px]">
                            <a href="/" className="rounded-full border border-[#ffffff] text-primary p-[5px_30px] m-[10px] w-[83.333333%] font-medium cursor-pointer transition duration-200 ease-in-out bg-[#ffffff] hover:bg-primary hover:text-[#ffffff] hover:border-[#fffff]">Sign Up</a> 
                            <a href="/" className="rounded-full border border-[#ffffff] text-[#ffffff] bg-[#f55d4b] p-[5px_32px] m-[10px] font-medium w-[83.333333%] cursor-pointer transition duration-200 ease-in-out hover:bg-[#ffffff] hover:text-primary  hover:border-primary">Dates</a> 
                            </div>
                        </div>
                    </div>

                </div>
            </div>
    )
}
export default Discover;