import React from "react"; 
import BtnPrm from "./extend/Btn/BtnPrm";

function Application() 
{ 
    return (
        <div id="reservation" className="hidden bg-[url('images/o-form.png'),_url('images/blank-business-composition.png')] bg-no-repeat bg-[position:left_center,_center] relative flex">
            <div className="p-[100px_0] w-[70%] m-[0_auto]">
                <div className="ml-auto mr-auto mb-[20px]">
                    <div className="relative mb-[24px]">
                        <h1 className="text-center text-[62px] text-[#ffffff]">APPLICATION</h1>
                        <h5 className="m-0 text-center text-[1.6rem] leading-[110%]">SIGN UP AND DISCOVER THE WORLD OF #PHP</h5>
                    </div>
                </div>
                <div className="ml-auto mr-auto mb-[20px]">
                    <form action="" id="contact form" method="post">
                        <div className="xl:ml-[16.6%] xl:w-[66%] float-left bg-[#ffffff] p-[0_0_60px] rounded-2xl w-auto">
                            <div className="h-[50px] bg-primary rounded-[10px_10px_0_0]"></div>
                            <div className="bg-[#ffffff] p-[40px]">
                                <div className="xl:ml-[-0.75rem] mr-[-0.75rem]">
                                    <div className="xl:w-[50%] ml-auto float-left p-[0_0.75rem] relative w-100%">
                                        <div className="w-[100%] relative, float-left mb-[1rem] flex">
                                            <input type="text" id="name" name="name" className="bg-transparent border-[0px] border-b-[1px] border-b-[#9e9e9e] outline-0 h-[3rem] w-[100%] text-[16px] m-[0_0_8px_0] p-0 "/>
                                            <label id="name" className="text-primary absolute left-[11px] text-[1rem] cursor-text translate-y-[12px] w-fit z-2">Name</label>
                                        </div>
                                        <div className="w-[100%] relative, float-left mb-[1rem]">
                                            <input type="email" id="email" name="email" className="bg-transparent border-[0px] border-b-[1px] border-b-[#9e9e9e] outline-0 h-[3rem] w-[100%] text-[16px] m-[0_0_8px_0] p-0 "/>
                                            <label id="email" className="text-primary absolute left-[11px] text-[1rem] cursor-text translate-y-[12px] w-fit z-2">Email</label>
                                        </div>
                                        <div className="w-[100%] relative, float-left mb-[1rem]">
                                            <input type="text" id="phone" name="phone" className="bg-transparent border-[0px] border-b-[1px] border-b-[#9e9e9e] outline-0 h-[3rem] w-[100%] text-[16px] m-[0_0_8px_0] p-0 "/>
                                            <label id="phone" className="text-primary absolute left-[11px] text-[1rem] cursor-text translate-y-[12px] w-fit z-2">Phone</label>
                                        </div>
                                        <div className="hidden xl:block">
                                        <BtnPrm description="Sign up"/>
                                        </div>
                                    </div>
                                    <div className="xl:w-[50%] ml-auto float-left p-[0_0.75rem] w-[100%]">
                                        <div className="w-[100%] relative, float-left mb-[1rem]">
                                        <div className="">
                                    <select id="type" name="type" className="w-full outline-none border-b border-[#9e9e9e] h-12 mb-2">
                                        <option value="Regular">Regular Access</option>
                                        <option value="Early">Early Access</option>
                                        <option value="Student">Student Academy</option>
                                    </select> 
                                </div>
                                <label className="w-full relative left-3 top-[-70px] text-[0.8rem] text-primary left-[2px]">
                                    Course Price
                                </label>
                                        </div>
                                        <div className="w-[100%] relative, float-left mb-[1rem]">
                                        <div className="">
                                    <select id="type" name="type" className="w-full outline-none border-b border-[#9e9e9e] h-12 mb-2">
                                        <option value="Feb">7.2. - 11.2.2022</option>
                                        <option value="Apr">4.4. - 8.4.2022</option>
                                        <option value="June">6.6 - 10.6.2022</option>
                                    </select>
                                </div>
                                <label className="w-full relative left-3 top-[-70px] text-[0.8rem] text-primary left-[2px]">
                                    Date
                                </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="xl:hidden block text-center">
                                <BtnPrm description="Sign up"/>
                            </div>                   
                        </div>
                        
                    </form>
                </div>
                
                <div className="ml-auto mr-auto mb-[20px]"></div>
            </div>
        </div>
    )
}

export default Application;