import React from "react";

function Timeline () { 
    return ( 
        <div>
            <div className="hidden xl:block ml-auto mr-auto mb-[20px]">
                <div className="text-center">
                    <div className="m-[100px_0_24px_0]">
                        <h1 className="m-0 text-gray-300 text-[62px]">TRAINING TIMELINE</h1>
                        <h5 className="relative m-0 text-[1.6rem]">THE MAIN TOPICS</h5>
                    </div>
                </div>
            </div>
            <div className="ml-auto mr-auto xl:mb-[20px] mb-[2px]">
                    <div className="hidden xl:block ml-[25%] w-[50%]">
                        <p className="text-center">We selected the PHP Academy topics to give you the knowledge and tips & tricks helpful for both small and large projects.</p>
                    </div>
            </div>
            <div className="hidden xl:block ml-auto mr-auto mb-[20px] hidden xl:block">
                <div className="ml-[8.33333%] w-[83%]">
                    <table className="xl:bg-[url('images/timeline.png')] bg-no-repeat bg-[position:center] m-[60px_0_100px_0] bg-contain w-[100%]">
                        <tbody>
                            <tr>
                                <td className="w-[3%] p-[25px_22px_22px_8px]"></td>
                                <td className="w-[13%] p-[25px_22px_22px_8px]"></td>
                                <td className="w-[18%] p-[25px_22px_22px_8px]">
                                    <h6 className="font-semibold m-0">PostgreSQL and DIBI</h6>
                                    <p >Database abstraction library</p>
                                    <span className="text-[12px] text-primary">2nd topic</span>
                                </td>
                                <td className="w-[15%] p-[25px_22px_22px_8px]"></td>
                                <td className="w-[16%] p-[25px_22px_22px_8px]">
                                    <h6 className="m-0 font-semibold">Advanced<br />techniques</h6>
                                    <p>PHP made more efficient</p>
                                    <span className="text-[12px] text-primary">4th topic</span>
                                </td>
                                <td className="w-[15%] p-[25px_22px_22px_8px]"></td>
                                <td className="w-[9%] p-[25px_22px_22px_8px]">
                                    <h6 className="m-0 font-semibold">AJAX</h6>
                                    <p>JSON</p>
                                    <span className="text-[12px] text-primary">6th topic</span>
                                </td>
                                <td className="w-[11%] p-[25px_22px_22px_8px]"></td>
                            </tr>
                            <tr>
                                <td className="w-[3%] p-[25px_22px_22px_8px]"></td>
                                <td className="w-[13%] p-[25px_22px_22px_8px]">
                                <h6 className="font-semibold m-0">OOP in PHP</h6>
                                    <p >Program as a kit set</p>
                                    <span className="text-[12px] text-primary">1st topic</span>
                                </td>
                                <td className="w-[18%] p-[25px_22px_22px_8px]"></td>
                                <td className="w-[15%] p-[25px_22px_22px_8px]">
                                    <h6 className="m-0 font-semibold">Application<br />architecture</h6>
                                    <p>Design patterns</p>
                                    <span className="text-[12px] text-primary">3rd topic</span>
                                </td>
                                <td className="w-[16%] p-[25px_22px_22px_8px]"></td>
                                <td className="w-[15%] p-[25px_22px_22px_8px]">
                                    <h6 className="m-0 font-semibold">SECURITY</h6>
                                    <p>Common vulnerabilities</p>
                                    <span className="text-[12px] text-primary">5th topic</span>
                                </td>
                                <td className="w-[9%] p-[25px_22px_22px_8px]"></td>
                                <td className="w-[11%] p-[25px_22px_22px_8px]">
                                    <h6 className="m-0 font-semibold">Integrations</h6>
                                    <p>SOAP, REST API</p>
                                    <span className="text-[12px] text-primary">7th topic</span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    )
}
export default Timeline;