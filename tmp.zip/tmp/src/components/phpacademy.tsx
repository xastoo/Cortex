
import React, {} from 'react';
import BigNumber from './extend/BigNumber';


function PhpAcademy(){
    

    
        return (

    <div id='phpacademy' className="xl:bg-[url('images/o-php-academy.png'),_url('images/ipad.png')] bg-no-repeat bg-[position:left_center,_right] xl:bg-[auto,_auto]">
        <div className="z-10 bg-[url('images/ipad.png')] bg-no-repeat bg-[right_center]"></div>
        <div className="p-[100px_0] xl:w-[70%] m-[0_auto]">
            <div className="ml-auto mr-auto mb-[20px] md:w-auto w-[90%]">
                <div className="xl:ml-[25%] md:w-[50%] m-auto w-[100%] xl:text-left text-center">
                    <div className="relative mb-[24px] text-center text-xl">
                        <h1 className="text-gray-200 xl:text-6xl md:text-4xl text-3xl text-[#DCDCDC]">PHP ACADEMY</h1>
                        <h5 className='md:text3xl text-xl xl:text-3xl'>TRAINING INTRODUCTION</h5>
                    </div>
                    <p>Interactive training focused on homing basic programming knowledge, learning Object-Oriented Programing, and mastering any framework. Thanks to this training, you will gain programming knowledge, for example, for e-shop creation.</p>
                    <br />
                    <p>Graduating from PHP Academy provides you with capabilities and knowledge at the level of a junior programmer.</p>
                    <br />
                    <p>Training takes place during five training days with four-hour tuition and one hour of consulting.</p>
                    <div className="xl:m-[0_100px_0_100px] overflow-hidden">
                        <h5 className="uppercase m-[60px_0] text-center text-3xl">Training focus</h5>
                        <p>Programmer Development</p>
                        <div className="relative h-[5px] bg-[#DFDFDF] m-[15px_0]">
                            <div className="absolute top-0 h-[5px] bg-primary w-[70%]"></div>
                        </div>
                        <p>Gaining Practical Experience</p>
                        <div className="relative h-[5px] bg-[#DFDFDF] m-[15px_0]">
                            <div className="absolute top-0 h-[5px] bg-primary w-[90%]"></div>
                        </div>
                        <p>Improved Code Understanding</p>
                        <div className="relative h-[5px] bg-[#DFDFDF] m-[15px_0]">
                            <div className="absolute top-0 h-[5px] bg-primary w-[85%]"></div>
                        </div>
                    </div>
                    
                        <h5 className="m-[80px_0_50px_0] text-center text-4xl">Additional Information</h5>
                    
                </div>
                
            </div>
            <div className="ml-auto mr-auto mb-[20px]">
                <div className="xl:text-left md:flex justify-center xl:flex-wrap w-full text-center block">
                    <BigNumber descriptionH4='10' descriptionP='Experienced Tutors' />
                    <BigNumber descriptionH4='7' descriptionP={<div>Main Topics<br />with Real-Life Examples</div>}/>
                    <BigNumber descriptionH4='20 +' descriptionP={<div>Hours of<br />Practical Tuition</div>} />
                    <BigNumber descriptionH4='100%' descriptionP='Individual Approach' />
                </div>
            </div>
        </div>
    </div>
    )    
}
export default PhpAcademy;