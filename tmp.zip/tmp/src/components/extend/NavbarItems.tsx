import React from "react";



interface NavbarItems{
    description: string;
    link?: string;
}

function NavbarItems({description, link}:NavbarItems) 
{ 
    return ( <li className="inline-block text-[#f55d4b] transition duration-300 ease-in-out hover:bg-[#000000]">
        <a href={`#${link}`} className="uppercase md:px-[15px] md:py-[21px] text-[#ffffff] md:w-auto w-[100%]">{description}</a> 
        </li>
    )
}
export default NavbarItems;