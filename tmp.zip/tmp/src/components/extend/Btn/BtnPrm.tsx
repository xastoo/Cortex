import React from "react";



interface BtnPrm{
    description: string;
    link?: string;
}

function BtnPrm({description, link}:BtnPrm) 
{ 
    return (
        <a href={`#${link}`} className="rounded-full border border-[#f55d4b] text-[#ffffff] bg-[#f55d4b] p-[3px_32px] m-[10px] w-[83.333333%] cursor-pointer transition duration-200 ease-in-out hover:bg-[#ffffff] hover:text-[#f55d4b]">{description}</a>
    )
}
export default BtnPrm;