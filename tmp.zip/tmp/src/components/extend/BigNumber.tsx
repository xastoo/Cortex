import React from "react";

interface BigNumber{
    descriptionH4: string;
    descriptionP: React.ReactNode;
}

function BigNumber({descriptionH4, descriptionP}:BigNumber) 
{ 
    return (
            <div className="md:w-[220px] self-start md:m-[5px] md:mb-0 mb-[20px]">
                <h4 className="md:text-4xl text-3xl">{descriptionH4}</h4>
                <p>{descriptionP}</p>
            </div>
        )
}
export default BigNumber;