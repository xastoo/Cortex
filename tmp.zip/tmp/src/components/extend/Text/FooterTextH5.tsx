import React from "react";


interface FooterTextH5{
    description: string;
}


export default function FooterTextH5({description}:FooterTextH5) 
{ 
    return (
        <h5 className="mt-0 md:text-[1.64rem] text-[1.3rem] m-[1rem_0_0.656rem_0] font-semibold">{description}</h5>
        )
}
